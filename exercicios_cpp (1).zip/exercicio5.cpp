#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

int main() {
    string nome;
    int idade;
    float n1, n2, n3, media;

    cout << "Digite o nome do aluno: ";
    getline(cin, nome);

    cout << "Digite a idade: ";
    cin >> idade;

    cout << "Digite tres notas: ";
    cin >> n1 >> n2 >> n3;

    media = (n1 + n2 + n3) / 3;

    cout << fixed << setprecision(2);

    cout << "\n--- Dados ---\n";
    cout << "Nome: " << nome << endl;
    cout << "Idade: " << idade << endl;
    cout << "Notas: " << n1 << ", " << n2 << ", " << n3 << endl;
    cout << "Media: " << media << endl;

    return 0;
}
