#include <iostream>
using namespace std;

int main() {
    int a, b, c;

    cout << "Digite tres valores: ";
    cin >> a >> b >> c;

    cout << "\nValores digitados: " << a << " " << b << " " << c << endl;

    return 0;
}
