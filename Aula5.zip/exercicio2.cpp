#include <iostream>

using namespace std;

int main() {
    double a[100];
    double *aPtr = a;

    int n;
    double soma = 0.0;

    cout << "Quantos valores deseja digitar? ";
    cin >> n;

    if (n > 100) {
        cout << "Quantidade maxima permitida: 100" << endl;
        return 1;
    }

    for (int j = 0; j < n; j++) {
        cout << "Digite o valor " << j + 1 << ": ";
        cin >> *(a + j);
    }

    for (int j = 0; j < n; j++) {
        soma += *(aPtr + j);
    }

    double media = soma / n;

    cout << "\nSoma dos valores: " << soma << endl;
    cout << "Media dos valores: " << media << endl;

    return 0;
}
