#include <iostream>
using namespace std;

int main() {
    int n;
    cout << "Digite um numero: ";
    cin >> n;

    int soma = 0;

    for(int i = 1; i < n; i++) {
        if(n % i == 0) {
            soma += i;
        }
        if(soma > n) break;
    }

    if(soma == n)
        cout << "Numero perfeito\n";
    else
        cout << "Nao e perfeito\n";

    return 0;
}
