#include <iostream>
using namespace std;

int main() {
    int idade, autorizacao, nivel;

    cout << "Digite a idade: ";
    cin >> idade;

    cout << "Possui autorizacao? (1=sim, 0=nao): ";
    cin >> autorizacao;

    cout << "Digite o nivel (1 a 3): ";
    cin >> nivel;

    if (idade < 16) {
        cout << "Acesso negado\n";
    } else if (idade <= 17) {
        if (autorizacao == 1) {
            cout << "Acesso permitido com autorizacao\n";
        } else {
            cout << "Precisa de autorizacao\n";
        }
    } else {
        switch(nivel) {
            case 1: cout << "Acesso basico\n"; break;
            case 2: cout << "Acesso intermediario\n"; break;
            case 3: cout << "Acesso total\n"; break;
            default: cout << "Nivel invalido\n";
        }
    }

    return 0;
}
