#include <iostream>
using namespace std;

int main() {
    double saldo = 1000;
    int opcao;

    do {
        cout << "\n1. Ver saldo\n2. Depositar\n3. Sacar\n4. Sair\n";
        cout << "Escolha: ";
        cin >> opcao;

        switch(opcao) {
            case 1:
                cout << "Saldo: " << saldo << endl;
                break;
            case 2: {
                double valor;
                cout << "Valor para depositar: ";
                cin >> valor;
                if (valor > 0) saldo += valor;
                else cout << "Valor invalido\n";
                break;
            }
            case 3: {
                double valor;
                cout << "Valor para sacar: ";
                cin >> valor;
                if (valor > 0 && valor <= saldo) saldo -= valor;
                else cout << "Saque invalido\n";
                break;
            }
            case 4:
                cout << "Saindo...\n";
                break;
            default:
                cout << "Opcao invalida\n";
        }

    } while(opcao != 4);

    return 0;
}
