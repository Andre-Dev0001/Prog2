#include <iostream>
using namespace std;

inline double converter(double dolares) {
    return dolares * 5.0;
}

int main() {
    double valor;
    cin >> valor;
    cout << converter(valor);
    return 0;
}
