#include <iostream>
using namespace std;

#define ANO 2
#define TRIMESTRE 4

int main() {
    double despesas[ANO][TRIMESTRE];
    double total = 0;

    for (int i = 0; i < ANO; i++) {
        for (int j = 0; j < TRIMESTRE; j++) {
            cin >> despesas[i][j];
            total += despesas[i][j];
        }
    }

    for (int i = 0; i < ANO; i++) {
        for (int j = 0; j < TRIMESTRE; j++) {
            cout << despesas[i][j] << " ";
        }
        cout << endl;
    }

    cout << total;

    return 0;
}
