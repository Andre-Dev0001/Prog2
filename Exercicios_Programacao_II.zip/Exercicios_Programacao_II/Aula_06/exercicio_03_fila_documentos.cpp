#include <iostream>
#include <queue>
#include <string>
#include <limits>

int main() {
    std::queue<std::string> documentos;
    int opcao;

    do {
        std::cout << "\n1 - Adicionar documento\n2 - Processar proximo\n3 - Consultar proximo\n4 - Quantidade na fila\n0 - Sair\nOpcao: ";
        std::cin >> opcao;
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

        if (opcao == 1) {
            std::string documento;
            std::cout << "Nome do documento: ";
            std::getline(std::cin, documento);
            documentos.push(documento);
        } else if (opcao == 2) {
            if (documentos.empty()) std::cout << "Fila vazia.\n";
            else {
                std::cout << "Processado: " << documentos.front() << '\n';
                documentos.pop();
            }
        } else if (opcao == 3) {
            if (documentos.empty()) std::cout << "Fila vazia.\n";
            else std::cout << "Proximo: " << documentos.front() << '\n';
        } else if (opcao == 4) {
            std::cout << "Quantidade: " << documentos.size() << '\n';
        }
    } while (opcao != 0);

    return 0;
}
