#include <iostream>
#include <stack>
#include <string>
#include <limits>
#include <vector>
#include <algorithm>

void exibirTexto(std::stack<std::string> palavras) {
    std::vector<std::string> texto;
    while (!palavras.empty()) {
        texto.push_back(palavras.top());
        palavras.pop();
    }
    std::reverse(texto.begin(), texto.end());
    for (const std::string& palavra : texto) std::cout << palavra << ' ';
    std::cout << '\n';
}

int main() {
    std::stack<std::string> palavras;
    int opcao;

    do {
        std::cout << "\n1 - Digitar palavra\n2 - Desfazer ultima palavra\n3 - Exibir texto\n0 - Sair\nOpcao: ";
        std::cin >> opcao;
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

        if (opcao == 1) {
            std::string palavra;
            std::cout << "Palavra: ";
            std::getline(std::cin, palavra);
            palavras.push(palavra);
        } else if (opcao == 2) {
            if (palavras.empty()) std::cout << "Nao ha palavras para desfazer.\n";
            else palavras.pop();
        } else if (opcao == 3) {
            exibirTexto(palavras);
        }
    } while (opcao != 0);

    return 0;
}
