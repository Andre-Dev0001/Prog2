#include <iostream>
#include <list>

int main() {
    std::list<int> valores;
    int opcao;

    do {
        std::cout << "\n1 - Inserir no inicio\n2 - Inserir no final\n3 - Remover por valor\n4 - Exibir lista\n5 - Exibir tamanho\n0 - Sair\nOpcao: ";
        std::cin >> opcao;

        if (opcao == 1 || opcao == 2) {
            int valor;
            std::cout << "Valor: ";
            std::cin >> valor;
            if (opcao == 1) valores.push_front(valor);
            else valores.push_back(valor);
        } else if (opcao == 3) {
            int valor;
            std::cout << "Valor a remover: ";
            std::cin >> valor;
            valores.remove(valor);
        } else if (opcao == 4) {
            if (valores.empty()) std::cout << "Lista vazia.\n";
            else {
                for (int valor : valores) std::cout << valor << ' ';
                std::cout << '\n';
            }
        } else if (opcao == 5) {
            std::cout << "Tamanho: " << valores.size() << '\n';
        }
    } while (opcao != 0);

    return 0;
}
