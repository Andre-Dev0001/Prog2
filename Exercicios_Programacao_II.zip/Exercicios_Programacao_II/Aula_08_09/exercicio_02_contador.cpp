#include <iostream>
#include <stdexcept>

class Contador {
private:
    int valor;

public:
    explicit Contador(int valor = 1) : valor(valor) {
        if (valor <= 0) throw std::invalid_argument("O valor deve ser positivo");
    }

    int getValor() const {
        return valor;
    }

    Contador& operator++() {
        ++valor;
        return *this;
    }

    Contador operator++(int) {
        Contador copia(*this);
        ++valor;
        return copia;
    }
};

int main() {
    Contador contador(5);
    std::cout << "Inicial: " << contador.getValor() << '\n';
    std::cout << "Pre-fixado: " << (++contador).getValor() << '\n';
    std::cout << "Pos-fixado retornou: " << (contador++).getValor() << '\n';
    std::cout << "Valor atual: " << contador.getValor() << '\n';
    return 0;
}
