#include <iostream>
#include <string>
#include <utility>

class StringSegura {
private:
    std::string valor;

public:
    StringSegura() = default;
    explicit StringSegura(std::string valor) : valor(std::move(valor)) {}
    ~StringSegura() = default;

    StringSegura(const StringSegura&) = delete;
    StringSegura& operator=(const StringSegura&) = delete;

    StringSegura(StringSegura&&) noexcept = default;
    StringSegura& operator=(StringSegura&&) noexcept = default;

    const std::string& getValor() const {
        return valor;
    }
};

int main() {
    StringSegura primeira("Conteudo protegido");
    StringSegura segunda = std::move(primeira);
    StringSegura terceira;
    terceira = std::move(segunda);
    std::cout << terceira.getValor() << '\n';
    return 0;
}
