#include <iostream>
#include <stdexcept>

class MatrizDinamica {
private:
    int linhas;
    int colunas;
    int** dados;

    void alocar() {
        dados = new int*[linhas];
        for (int i = 0; i < linhas; ++i) dados[i] = new int[colunas]{};
    }

    void liberar() {
        for (int i = 0; i < linhas; ++i) delete[] dados[i];
        delete[] dados;
    }

public:
    MatrizDinamica(int linhas, int colunas) : linhas(linhas), colunas(colunas), dados(nullptr) {
        if (linhas <= 0 || colunas <= 0) throw std::invalid_argument("Dimensoes invalidas");
        alocar();
    }

    MatrizDinamica(const MatrizDinamica& outra) : linhas(outra.linhas), colunas(outra.colunas), dados(nullptr) {
        alocar();
        for (int i = 0; i < linhas; ++i)
            for (int j = 0; j < colunas; ++j)
                dados[i][j] = outra.dados[i][j];
    }

    MatrizDinamica& operator=(const MatrizDinamica& outra) {
        if (this != &outra) {
            MatrizDinamica copia(outra);
            std::swap(linhas, copia.linhas);
            std::swap(colunas, copia.colunas);
            std::swap(dados, copia.dados);
        }
        return *this;
    }

    ~MatrizDinamica() {
        liberar();
    }

    int& at(int linha, int coluna) {
        if (linha < 0 || linha >= linhas || coluna < 0 || coluna >= colunas) throw std::out_of_range("Indice invalido");
        return dados[linha][coluna];
    }

    int at(int linha, int coluna) const {
        if (linha < 0 || linha >= linhas || coluna < 0 || coluna >= colunas) throw std::out_of_range("Indice invalido");
        return dados[linha][coluna];
    }

    void exibir() const {
        for (int i = 0; i < linhas; ++i) {
            for (int j = 0; j < colunas; ++j) std::cout << dados[i][j] << ' ';
            std::cout << '\n';
        }
    }
};

int main() {
    MatrizDinamica matriz(2, 3);
    matriz.at(0, 0) = 10;
    matriz.at(1, 2) = 20;

    MatrizDinamica copia = matriz;
    copia.at(0, 0) = 99;

    std::cout << "Original:\n";
    matriz.exibir();
    std::cout << "Copia:\n";
    copia.exibir();
    return 0;
}
