#include <iostream>
#include <string>

class ContaBancaria {
private:
    std::string numeroConta;
    double saldo;

public:
    explicit ContaBancaria(const std::string& numeroConta) : numeroConta(numeroConta), saldo(0.0) {}

    double getSaldo() const {
        return saldo;
    }

    bool depositar(double valor) {
        if (valor <= 0) return false;
        saldo += valor;
        return true;
    }

    bool sacar(double valor) {
        if (valor <= 0 || valor > saldo) return false;
        saldo -= valor;
        return true;
    }

    std::string getNumeroConta() const {
        return numeroConta;
    }
};

int main() {
    ContaBancaria conta("12345-6");
    conta.depositar(1000.0);
    conta.sacar(250.0);
    std::cout << "Conta: " << conta.getNumeroConta() << '\n';
    std::cout << "Saldo: R$ " << conta.getSaldo() << '\n';
    return 0;
}
