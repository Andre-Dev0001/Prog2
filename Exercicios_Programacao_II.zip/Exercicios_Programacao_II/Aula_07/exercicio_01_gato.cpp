#include <iostream>
#include <string>

class Gato {
private:
    std::string nome;
    int idade;
    double peso;

public:
    Gato(const std::string& nome, int idade, double peso) : nome(nome), idade(idade), peso(0.0) {
        setPeso(peso);
    }

    void setPeso(double novoPeso) {
        if (novoPeso > 0) peso = novoPeso;
    }

    void exibir() const {
        std::cout << "Nome: " << nome << "\nIdade: " << idade << "\nPeso: " << peso << " kg\n";
    }
};

int main() {
    Gato gato("Mingau", 3, 4.8);
    gato.setPeso(-2.0);
    gato.exibir();
    return 0;
}
