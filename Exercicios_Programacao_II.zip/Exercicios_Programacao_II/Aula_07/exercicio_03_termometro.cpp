#include <iostream>

class Termometro {
private:
    double temperaturaCelsius;

public:
    Termometro() : temperaturaCelsius(25.0) {}

    bool setTemperaturaCelsius(double temperatura) {
        if (temperatura < -273.15) return false;
        temperaturaCelsius = temperatura;
        return true;
    }

    double getTemperaturaCelsius() const {
        return temperaturaCelsius;
    }

    double getTemperaturaFahrenheit() const {
        return temperaturaCelsius * 9.0 / 5.0 + 32.0;
    }
};

int main() {
    Termometro termometro;
    termometro.setTemperaturaCelsius(30.0);
    std::cout << "Celsius: " << termometro.getTemperaturaCelsius() << '\n';
    std::cout << "Fahrenheit: " << termometro.getTemperaturaFahrenheit() << '\n';
    return 0;
}
