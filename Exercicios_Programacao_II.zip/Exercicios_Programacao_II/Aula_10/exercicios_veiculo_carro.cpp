#include <iostream>
#include <string>

class Veiculo {
public:
    std::string marca;

    explicit Veiculo(const std::string& marca) : marca(marca) {}

    virtual void emitirSom() const {
        std::cout << "O veiculo emite um ruido de motor." << std::endl;
    }

    virtual ~Veiculo() = default;
};

class Carro : public Veiculo {
public:
    int numeroPortas;

    Carro(const std::string& marca, int numeroPortas) : Veiculo(marca), numeroPortas(numeroPortas) {}

    void emitirSom() const override {
        std::cout << "Bip bip! Som da buzina do carro." << std::endl;
    }
};

int main() {
    Veiculo veiculo("Generica");
    Carro carro("Toyota", 4);

    std::cout << "Veiculo: " << veiculo.marca << '\n';
    veiculo.emitirSom();

    std::cout << "Carro: " << carro.marca << ", portas: " << carro.numeroPortas << '\n';
    carro.emitirSom();

    Veiculo* referencia = &carro;
    referencia->emitirSom();
    return 0;
}
